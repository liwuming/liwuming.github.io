# `@docusaurus/plugin-content-blog`

Blog plugin for Docusaurus.

## Usage

See [plugin-content-blog documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-content-blog).
