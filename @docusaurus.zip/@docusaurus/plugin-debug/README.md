# `@docusaurus/plugin-debug`

Debug plugin for Docusaurus.

## Usage

See [plugin-debug documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-debug).
