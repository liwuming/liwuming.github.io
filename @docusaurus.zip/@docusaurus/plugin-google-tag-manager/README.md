# `@docusaurus/plugin-google-tag-manager`

Google Tag Manager plugin for Docusaurus.

## Usage

See [plugin-google-tag-manager documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-google-tag-manager).
