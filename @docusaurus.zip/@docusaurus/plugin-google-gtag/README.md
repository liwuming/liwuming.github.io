# `@docusaurus/plugin-google-gtag`

Global Site Tag (gtag.js) plugin for Docusaurus.

## Usage

See [plugin-google-gtag documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-google-gtag).
