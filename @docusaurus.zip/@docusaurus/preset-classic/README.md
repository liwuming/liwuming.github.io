# `@docusaurus/preset-classic`

Classic preset for Docusaurus.

## Usage

See [presets documentation](https://docusaurus.io/docs/using-plugins#using-presets).
