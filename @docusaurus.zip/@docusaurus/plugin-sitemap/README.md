# `@docusaurus/plugin-sitemap`

Simple sitemap generation plugin for Docusaurus.

## Usage

See [plugin-sitemap documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-sitemap).
