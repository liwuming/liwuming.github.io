# `@docusaurus/plugin-google-analytics`

Google analytics plugin for Docusaurus.

## Usage

See [plugin-google-analytics documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-google-analytics).
