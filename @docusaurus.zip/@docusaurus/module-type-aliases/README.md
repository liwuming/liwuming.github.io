# `@docusaurus/module-type-aliases`

Docusaurus module type aliases.
