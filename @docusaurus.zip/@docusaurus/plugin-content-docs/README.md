# `@docusaurus/plugin-content-docs`

Docs plugin for Docusaurus.

## Usage

See [plugin-content-docs documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-content-docs).
