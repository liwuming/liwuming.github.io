# `@docusaurus/cssnano-preset`

An advanced cssnano preset for maximum optimization.
