# `@docusaurus/plugin-content-pages`

Pages plugin for Docusaurus.

## Usage

See [plugin-content-pages documentation](https://docusaurus.io/docs/api/plugins/@docusaurus/plugin-content-pages).
