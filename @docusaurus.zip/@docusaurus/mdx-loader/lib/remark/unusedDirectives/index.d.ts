type Plugin = any;
declare const plugin: Plugin;
export default plugin;
//# sourceMappingURL=index.d.ts.map